package gohleng.apps.mobileblog.home

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import gohleng.apps.mobileblog.R

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

}